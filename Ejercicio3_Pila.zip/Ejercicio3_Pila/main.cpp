#include <stdio.h>
#include "pila.h"
#include "ordenamientos.h"

int main() {
    Pila p;
    inicializar(&p);

    int opcion, num;

    do {
        printf("\n--- MENU PILA ---\n");
        printf("1. Push\n");
        printf("2. Pop\n");
        printf("3. Mostrar\n");
        printf("4. Ordenar Burbuja\n");
        printf("5. Ordenar QuickSort\n");
        printf("6. Ordenar MergeSort\n");
        printf("7. Salir\n");
        printf("Opcion: ");
        scanf("%d", &opcion);

        switch (opcion) {
            case 1:
                printf("Numero: ");
                scanf("%d", &num);
                push(&p, num);
                break;

            case 2:
                printf("Eliminado: %d\n", pop(&p));
                break;

            case 3:
                mostrar(&p);
                break;

            case 4:
                burbuja(p.datos, tamano(&p));
                printf("Ordenado con Burbuja\n");
                break;

            case 5:
                quickSort(p.datos, 0, tamano(&p) - 1);
                printf("Ordenado con QuickSort\n");
                break;

            case 6:
                mergeSort(p.datos, 0, tamano(&p) - 1);
                printf("Ordenado con MergeSort\n");
                break;

            case 7:
                printf("Saliendo...\n");
                break;

            default:
                printf("Opcion invalida\n");
        }

    } while (opcion != 7);

    return 0;
}