#ifndef ORDENAMIENTOS_H
#define ORDENAMIENTOS_H

void burbuja(int arr[], int n);
void quickSort(int arr[], int low, int high);
void mergeSort(int arr[], int left, int right);

#endif