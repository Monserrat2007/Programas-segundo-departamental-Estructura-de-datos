#include <stdio.h>
#include "pila.h"

void inicializar(Pila *p) {
	p->tope = -1;
}

void push(Pila *p, int valor) {
	if (p->tope < MAX - 1) {
		p->datos[++p->tope] = valor;
		printf("Elemento agregado \n");
	} else {
		printf("Pila llena \n");
	}
}

int pop(Pila *p) {
	if (!estaVacia(p)) {
		return p->datos[p->tope--];
	}
	printf("Pila vacia \n");
	return -1;
}

int estaVacia(Pila *p) {
	return p->tope == MAX -1;
}

void mostrar(Pila *p) {
	if (estaVacia(p)) {
		printf("Pila vacia \n");
		return;
	}
	
	for (int i = p->tope; i >= 0; i--) {
		printf("%d \n", p->datos[i]);
	}
}

int tamano(Pila*p) {
	return p->tope + 1;
}