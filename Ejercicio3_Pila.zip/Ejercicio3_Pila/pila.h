#ifndef PILA_H
#define PILA_H

#define MAX 50

typedef struct {
	int datos[MAX];
	int tope;
} Pila;

void inicializar(Pila *p);
void push(Pila *p, int valor);
int pop(Pila *p);
int estaVacia(Pila *p);
int estaLlena(Pila *p);
void mostrar(Pila *p);
int tamano(Pila *p);

#endif