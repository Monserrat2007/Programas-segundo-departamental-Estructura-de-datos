#include "Persona.h"

void Persona::setPersona(string n, string ap_, string am_, string g, int e, float precio, int anio) {
    nombre = n;
    ap = ap_;
    am = am_;
    genero = g;
    edad = e;
    autos.setAuto(precio, anio);
}

void Persona::mostrarPersona() {
    cout << "Nombre: " << nombre << " " << ap << " " << am << endl;
    cout << "Genero: " << genero << " | Edad: " << edad << endl;
    autos.mostrarAuto();
    cout << "---------------------" << endl;
}
