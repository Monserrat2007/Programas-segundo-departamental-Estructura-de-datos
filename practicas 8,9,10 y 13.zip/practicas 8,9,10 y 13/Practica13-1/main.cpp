#include <iostream>
#include "Persona.h"
using namespace std;

int main() {
    int N;

    cout << "Cuantas personas: ";
    cin >> N;

    //  PUNTERO A ARREGLO DINAMICO
    Persona *personas = new Persona[N];

    // Llenado
    for (int i = 0; i < N; i++) {
        string nombre, ap, am, genero;
        int edad;
        float precio;
        int anio;

        cout << "\n--- Persona " << i+1 << " " << endl;

        cout << "Nombre: ";
        cin >> nombre;
        cout << "Apellido paterno: ";
        cin >> ap;
        cout << "Apellido materno: ";
        cin >> am;
        cout << "Genero: ";
        cin >> genero;
        cout << "Edad: ";
        cin >> edad;

        cout << "Precio del auto: ";
        cin >> precio;
        cout << "Anio del auto: ";
        cin >> anio;

        // Accesos Indirecto
        (personas + i)->setPersona(nombre, ap, am, genero, edad, precio, anio);
    }

    // Mostrar
    cout << "\n=== LISTA DE PERSONAS ===" << endl;

    for (int i = 0; i < N; i++) {
        (personas + i)->mostrarPersona();
    }

    // Liberar memoria
    delete[] personas;

    return 0;
}
