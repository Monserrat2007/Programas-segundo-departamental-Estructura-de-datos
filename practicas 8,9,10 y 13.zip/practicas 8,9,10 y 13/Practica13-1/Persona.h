#ifndef PERSONA_H
#define PERSONA_H

#include <iostream>
#include "Auto.h"
using namespace std;

class Persona {
private:
    string nombre, ap, am, genero;
    int edad;
    Auto autos;

public:
    void setPersona(string n, string ap_, string am_, string g, int e, float precio, int anio);
    void mostrarPersona();
};

#endif
