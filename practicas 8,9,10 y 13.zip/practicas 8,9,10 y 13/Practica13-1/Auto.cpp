#include "Auto.h"

void Auto::setAuto(float p, int a) {
    precio = p;
    anio = a;
}

void Auto::mostrarAuto() {
    cout << "Precio: $" << precio << " | Anio: " << anio << endl;
}
