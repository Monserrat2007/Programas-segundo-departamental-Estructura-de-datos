#ifndef AUTO_H
#define AUTO_H

#include <iostream>
using namespace std;

class Auto {
private:
    float precio;
    int anio;

public:
    void setAuto(float p, int a);
    void mostrarAuto();
};

#endif
