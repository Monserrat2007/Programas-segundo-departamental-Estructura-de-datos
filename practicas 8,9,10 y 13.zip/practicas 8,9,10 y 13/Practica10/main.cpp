#include <iostream>
#include <list>
using namespace std;

int main() {
    list<int> lista;

    int opcion, dato;

    do {
        cout << "\n--- MENU LISTA ---" << endl;
        cout << "1. Insertar al inicio" << endl;
        cout << "2. Insertar al final" << endl;
        cout << "3. Eliminar inicio" << endl;
        cout << "4. Eliminar final" << endl;
        cout << "5. Mostrar lista" << endl;
        cout << "6. Ver si esta vacia" << endl;
        cout << "7. Salir" << endl;
        cout << "Opcion: ";

        cin >> opcion;

        if (cin.fail()) {
            cin.clear();
            cin.ignore(1000, '\n');
            opcion = 0;
        }

        switch(opcion) {
            case 1:
                cout << "Dato: ";
                cin >> dato;
                lista.push_front(dato);
                break;

            case 2:
                cout << "Dato: ";
                cin >> dato;
                lista.push_back(dato);
                break;

            case 3:
                if (!lista.empty()) {
                    lista.pop_front();
                } else {
                    cout << "Lista vacia" << endl;
                }
                break;

            case 4:
                if (!lista.empty()) {
                    lista.pop_back();
                } else {
                    cout << "Lista vacia" << endl;
                }
                break;

            case 5:
                if (!lista.empty()) {
                    cout << "Lista: ";
                    for (list<int>::iterator it = lista.begin(); it != lista.end(); it++) {
                        cout << *it << " ";
                    }
                    cout << endl;
                } else {
                    cout << "Lista vacia" << endl;
                }
                break;

            case 6:
                if (lista.empty()) {
                    cout << "Lista vacia" << endl;
                } else {
                    cout << "Lista con elementos" << endl;
                }
                break;

        }

    } while(opcion != 7);

    return 0;
}
