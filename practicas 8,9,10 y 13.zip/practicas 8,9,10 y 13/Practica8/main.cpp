#include <iostream>
#include <stack>   //librería de pila
using namespace std;

int main() {
    stack<int> pila;  //pila dinámica

    int opcion, dato;

    do {
        cout << "\n--- MENU PILA ---" << endl;
        cout << "1. Insertar (push)" << endl;
        cout << "2. Eliminar (pop)" << endl;
        cout << "3. Mostrar cima (top)" << endl;
        cout << "4. Ver si esta vacia" << endl;
        cout << "5. Salir" << endl;
        cout << "Opcion: ";
        cin >> opcion;

        switch(opcion) {
            case 1:
                cout << "Ingresa dato: ";
                cin >> dato;
                pila.push(dato);
                break;

            case 2:
                if (!pila.empty()) {
                    cout << "Eliminado: " << pila.top() << endl;
                    pila.pop();
                } else {
                    cout << "La pila esta vacia" << endl;
                }
                break;

            case 3:
                if (!pila.empty()) {
                    cout << "Cima: " << pila.top() << endl;
                } else {
                    cout << "La pila esta vacia" << endl;
                }
                break;

            case 4:
                if (pila.empty()) {
                    cout << "La pila esta vacia" << endl;
                } else {
                    cout << "La pila tiene elementos" << endl;
                }
                break;
        }

    } while(opcion != 5);

    return 0;
}
