#include <iostream>
#include <queue>   // librería de cola
using namespace std;

int main() {
    queue<int> cola;  //cola dinámica

    int opcion, dato;

    do {
        cout << "\n--- MENU COLA ---" << endl;
        cout << "1. Insertar (push)" << endl;
        cout << "2. Eliminar (pop)" << endl;
        cout << "3. Mostrar frente (front)" << endl;
        cout << "4. Mostrar ultimo (back)" << endl;
        cout << "5. Ver si esta vacia" << endl;
        cout << "6. Salir" << endl;
        cout << "Opcion: ";
        cin >> opcion;

        switch(opcion) {
            case 1:
                cout << "Ingresa dato: ";
                cin >> dato;
                cola.push(dato);
                break;

            case 2:
                if (!cola.empty()) {
                    cout << "Eliminado: " << cola.front() << endl;
                    cola.pop();
                } else {
                    cout << "La cola esta vacia" << endl;
                }
                break;

            case 3:
                if (!cola.empty()) {
                    cout << "Frente: " << cola.front() << endl;
                } else {
                    cout << "La cola esta vacia" << endl;
                }
                break;

            case 4:
                if (!cola.empty()) {
                    cout << "Ultimo: " << cola.back() << endl;
                } else {
                    cout << "La cola esta vacia" << endl;
                }
                break;

            case 5:
                if (cola.empty()) {
                    cout << "La cola esta vacia" << endl;
                } else {
                    cout << "La cola tiene elementos" << endl;
                }
                break;
        }

    } while(opcion != 6);

    return 0;
}
