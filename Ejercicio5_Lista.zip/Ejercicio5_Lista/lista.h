#ifndef LISTA_H
#define LISTA_H

#define MAX 50

typedef struct {
    int datos[MAX];
    int tam;
} Lista;

void inicializar(Lista *l);
void insertar(Lista *l, int valor);
void eliminar(Lista *l, int valor);
int buscar(Lista *l, int valor);
void mostrar(Lista *l);
int estaLlena(Lista *l);
int estaVacia(Lista *l);

#endif