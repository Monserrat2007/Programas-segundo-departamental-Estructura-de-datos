#include <stdio.h>
#include "lista.h"
#include "ordenamientos.h"

int main() {
    Lista l;
    inicializar(&l);

    int opcion, num;

    do {
        printf("\n--- MENU LISTA ---\n");
        printf("1. Insertar\n");
        printf("2. Eliminar\n");
        printf("3. Buscar\n");
        printf("4. Mostrar\n");
        printf("5. Ordenar Burbuja\n");
        printf("6. Ordenar QuickSort\n");
        printf("7. Ordenar MergeSort\n");
        printf("8. Salir\n");
        printf("Opcion: ");
        scanf("%d", &opcion);

        switch(opcion) {
            case 1:
                printf("Numero: ");
                scanf("%d", &num);
                insertar(&l, num);
                break;

            case 2:
                printf("Numero a eliminar: ");
                scanf("%d", &num);
                eliminar(&l, num);
                break;

            case 3: {
				printf("Numero a buscar: ");
    			scanf("%d", &num);
    			int pos = buscar(&l, num);

    			if (pos != -1)
        		printf("Encontrado en posicion %d\n", pos);
    			else
        		printf("No encontrado\n");
    			break;
			}

            case 4:
                mostrar(&l);
                break;

            case 5:
                burbuja(l.datos, l.tam);
                printf("Ordenado con Burbuja\n");
                mostrar(&l);
                break;

            case 6:
                quickSort(l.datos, 0, l.tam - 1);
                printf("Ordenado con QuickSort\n");
                mostrar(&l);
                break;

            case 7:
                mergeSort(l.datos, 0, l.tam - 1);
                printf("Ordenado con MergeSort\n");
                mostrar(&l);
                break;

            case 8:
                printf("Salir\n");
                break;

            default:
                printf("Opcion invalida\n");
        }

    } while(opcion != 8);

    return 0;
}