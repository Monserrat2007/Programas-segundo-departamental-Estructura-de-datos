#include <stdio.h>
#include "lista.h"

void inicializar(Lista *l) {
    l->tam = 0;
}

int estaLlena(Lista *l) {
    return l->tam == MAX;
}

int estaVacia(Lista *l) {
    return l->tam == 0;
}

void insertar(Lista *l, int valor) {
    if (!estaLlena(l)) {
        l->datos[l->tam++] = valor;
        printf("Elemento insertado\n");
    } else {
        printf("Lista llena\n");
    }
}

int buscar(Lista *l, int valor) {
    for (int i = 0; i < l->tam; i++) {
        if (l->datos[i] == valor) {
            return i;
        }
    }
    return -1;
}

void eliminar(Lista *l, int valor) {
    int pos = buscar(l, valor);

    if (pos == -1) {
        printf("Elemento no encontrado\n");
        return;
    }

    for (int i = pos; i < l->tam - 1; i++) {
        l->datos[i] = l->datos[i + 1];
    }

    l->tam--;
    printf("Elemento eliminado\n");
}

void mostrar(Lista *l) {
    if (estaVacia(l)) {
        printf("Lista vacia\n");
        return;
    }

    for (int i = 0; i < l->tam; i++) {
        printf("%d\n", l->datos[i]);
    }
}