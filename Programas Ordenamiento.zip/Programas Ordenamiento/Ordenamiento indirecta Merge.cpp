#include <iostream>
#include <vector>
#include <string>

using namespace std;

// ================= NUEVO TIPO =================
struct Persona {
    string nombre;
    int edad;
};

// ================= INTERFAZ =================
class IOrdenamiento {
public:
    virtual void mergesort() = 0;
    virtual ~IOrdenamiento() {}
};

// ================= CLASE ABSTRACTA =================
class DatosBase {
protected:
    vector<int> enteros;
    vector<char> caracteres;
    vector<Persona> personas;

public:
    virtual void cargarDatos() = 0;
    virtual ~DatosBase() {}
};

// ================= IMPLEMENTACI�N =================
class Ordenamiento : public DatosBase, public IOrdenamiento {
private:
    vector<int> idxEnteros;
    vector<int> idxCaracteres;
    vector<int> idxPersonas;

public:

    // ----------- CARGA DE DATOS -----------
    void cargarDatos() {
        int n;

        cout << "Cantidad de enteros: ";
        cin >> n;
        for (int i = 0; i < n; i++) {
            int x;
            cin >> x;
            enteros.push_back(x);
            idxEnteros.push_back(i);
        }

        cout << "Cantidad de caracteres: ";
        cin >> n;
        for (int i = 0; i < n; i++) {
            char c;
            cin >> c;
            caracteres.push_back(c);
            idxCaracteres.push_back(i);
        }

        cout << "Cantidad de personas: ";
        cin >> n;
        for (int i = 0; i < n; i++) {
            Persona p;
            cout << "Nombre: ";
            cin >> p.nombre;
            cout << "Edad: ";
            cin >> p.edad;

            personas.push_back(p);
            idxPersonas.push_back(i);
        }
    }

    // ----------- MERGE ENTEROS -----------
    void mergeEnteros(int ini, int mid, int fin) {
        vector<int> temp;
        int i = ini, j = mid + 1;

        while (i <= mid && j <= fin) {
            if (enteros[idxEnteros[i]] <= enteros[idxEnteros[j]])
                temp.push_back(idxEnteros[i++]);
            else
                temp.push_back(idxEnteros[j++]);
        }

        while (i <= mid) temp.push_back(idxEnteros[i++]);
        while (j <= fin) temp.push_back(idxEnteros[j++]);

        for (int k = 0; k < temp.size(); k++)
            idxEnteros[ini + k] = temp[k];
    }

    void mergeSortEnteros(int ini, int fin) {
        if (ini < fin) {
            int mid = (ini + fin) / 2;
            mergeSortEnteros(ini, mid);
            mergeSortEnteros(mid + 1, fin);
            mergeEnteros(ini, mid, fin);
        }
    }

    // ----------- MERGE CARACTERES -----------
    void mergeCaracteres(int ini, int mid, int fin) {
        vector<int> temp;
        int i = ini, j = mid + 1;

        while (i <= mid && j <= fin) {
            if (caracteres[idxCaracteres[i]] <= caracteres[idxCaracteres[j]])
                temp.push_back(idxCaracteres[i++]);
            else
                temp.push_back(idxCaracteres[j++]);
        }

        while (i <= mid) temp.push_back(idxCaracteres[i++]);
        while (j <= fin) temp.push_back(idxCaracteres[j++]);

        for (int k = 0; k < temp.size(); k++)
            idxCaracteres[ini + k] = temp[k];
    }

    void mergeSortCaracteres(int ini, int fin) {
        if (ini < fin) {
            int mid = (ini + fin) / 2;
            mergeSortCaracteres(ini, mid);
            mergeSortCaracteres(mid + 1, fin);
            mergeCaracteres(ini, mid, fin);
        }
    }

    // ----------- MERGE PERSONAS -----------
    void mergePersonas(int ini, int mid, int fin) {
        vector<int> temp;
        int i = ini, j = mid + 1;

        while (i <= mid && j <= fin) {
            if (personas[idxPersonas[i]].edad <= personas[idxPersonas[j]].edad)
                temp.push_back(idxPersonas[i++]);
            else
                temp.push_back(idxPersonas[j++]);
        }

        while (i <= mid) temp.push_back(idxPersonas[i++]);
        while (j <= fin) temp.push_back(idxPersonas[j++]);

        for (int k = 0; k < temp.size(); k++)
            idxPersonas[ini + k] = temp[k];
    }

    void mergeSortPersonas(int ini, int fin) {
        if (ini < fin) {
            int mid = (ini + fin) / 2;
            mergeSortPersonas(ini, mid);
            mergeSortPersonas(mid + 1, fin);
            mergePersonas(ini, mid, fin);
        }
    }

    // ----------- M�TODO GENERAL -----------
    void mergesort() {
        if (!idxEnteros.empty())
            mergeSortEnteros(0, idxEnteros.size() - 1);

        if (!idxCaracteres.empty())
            mergeSortCaracteres(0, idxCaracteres.size() - 1);

        if (!idxPersonas.empty())
            mergeSortPersonas(0, idxPersonas.size() - 1);
    }

    // ----------- MOSTRAR -----------
    void mostrar() {

        cout << "\nEnteros ordenados:\n";
        for (int i = 0; i < idxEnteros.size(); i++)
            cout << enteros[idxEnteros[i]] << " ";

        cout << "\n\nCaracteres ordenados:\n";
        for (int i = 0; i < idxCaracteres.size(); i++)
            cout << caracteres[idxCaracteres[i]] << " ";

        cout << "\n\nPersonas ordenadas por edad:\n";
        for (int i = 0; i < idxPersonas.size(); i++)
            cout << personas[idxPersonas[i]].nombre
                 << " - "
                 << personas[idxPersonas[i]].edad << endl;
    }
};

// ================= MAIN =================
int main() {

    Ordenamiento obj;

    obj.cargarDatos();
    obj.mergesort();
    obj.mostrar();

    return 0;
}
