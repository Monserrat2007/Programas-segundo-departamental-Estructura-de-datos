#include <iostream>
#include <vector>
#include <string>

using namespace std;

// ================= NUEVO TIPO =================
struct Persona {
    string nombre;
    int edad;
};

// ================= INTERFAZ =================
class IOrdenamiento {
public:
    virtual void burbuja() = 0;
    virtual ~IOrdenamiento() {}
};

// ================= CLASE ABSTRACTA =================
class DatosBase {
protected:
    vector<int> enteros;
    vector<char> caracteres;
    vector<Persona> personas;

public:
    virtual void cargarDatos() = 0;
    virtual ~DatosBase() {}
};

// ================= IMPLEMENTACI�N =================
class Ordenamiento : public DatosBase, public IOrdenamiento {
private:
    vector<int> idxEnteros;
    vector<int> idxCaracteres;
    vector<int> idxPersonas;

public:

    void cargarDatos() {
        int n;

        // ENTEROS
        cout << "Cuantos enteros: ";
        cin >> n;
        for (int i = 0; i < n; i++) {
            int num;
            cin >> num;
            enteros.push_back(num);
            idxEnteros.push_back(i);
        }

        // CARACTERES
        cout << "Cuantos caracteres: ";
        cin >> n;
        for (int i = 0; i < n; i++) {
            char c;
            cin >> c;
            caracteres.push_back(c);
            idxCaracteres.push_back(i);
        }

        // PERSONAS
        cout << "Cuantas personas: ";
        cin >> n;
        for (int i = 0; i < n; i++) {
            Persona p;
            cout << "Nombre: ";
            cin >> p.nombre;
            cout << "Edad: ";
            cin >> p.edad;

            personas.push_back(p);
            idxPersonas.push_back(i);
        }
    }

    // ================= BURBUJA INDIRECTA =================

    void ordenarEnteros() {
        for (int i = 0; i < idxEnteros.size() - 1; i++) {
            for (int j = 0; j < idxEnteros.size() - i - 1; j++) {
                if (enteros[idxEnteros[j]] > enteros[idxEnteros[j + 1]]) {
                    swap(idxEnteros[j], idxEnteros[j + 1]);
                }
            }
        }
    }

    void ordenarCaracteres() {
        for (int i = 0; i < idxCaracteres.size() - 1; i++) {
            for (int j = 0; j < idxCaracteres.size() - i - 1; j++) {
                if (caracteres[idxCaracteres[j]] > caracteres[idxCaracteres[j + 1]]) {
                    swap(idxCaracteres[j], idxCaracteres[j + 1]);
                }
            }
        }
    }

    void ordenarPersonas() {
        for (int i = 0; i < idxPersonas.size() - 1; i++) {
            for (int j = 0; j < idxPersonas.size() - i - 1; j++) {
                if (personas[idxPersonas[j]].edad > personas[idxPersonas[j + 1]].edad) {
                    swap(idxPersonas[j], idxPersonas[j + 1]);
                }
            }
        }
    }

    void burbuja() {
        ordenarEnteros();
        ordenarCaracteres();
        ordenarPersonas();
    }

    void mostrar() {
        cout << "\nEnteros ordenados:\n";
        for (int i = 0; i < idxEnteros.size(); i++) {
            cout << enteros[idxEnteros[i]] << " ";
        }

        cout << "\n\nCaracteres ordenados:\n";
        for (int i = 0; i < idxCaracteres.size(); i++) {
            cout << caracteres[idxCaracteres[i]] << " ";
        }

        cout << "\n\nPersonas ordenadas por edad:\n";
        for (int i = 0; i < idxPersonas.size(); i++) {
            cout << personas[idxPersonas[i]].nombre 
                 << " - " 
                 << personas[idxPersonas[i]].edad << endl;
        }
    }
};

// ================= MAIN =================
int main() {
    Ordenamiento obj;

    obj.cargarDatos();
    obj.burbuja();
    obj.mostrar();

    return 0;
}
