#include <iostream>
#include <vector>
#include <string>

using namespace std;

// ================= NUEVO TIPO =================
struct Persona {
    string nombre;
    int edad;
};

// ================= INTERFAZ =================
class IOrdenamiento {
public:
    virtual void quicksort() = 0;
    virtual ~IOrdenamiento() {}
};

// ================= CLASE ABSTRACTA =================
class DatosBase {
protected:
    vector<int> enteros;
    vector<char> caracteres;
    vector<Persona> personas;

public:
    virtual void cargarDatos() = 0;
    virtual ~DatosBase() {}
};

// ================= IMPLEMENTACI�N =================
class Ordenamiento : public DatosBase, public IOrdenamiento {
private:
    vector<int> idxEnteros;
    vector<int> idxCaracteres;
    vector<int> idxPersonas;

public:

    void cargarDatos() {
        int n;

        // ENTEROS
        cout << "Cuantos enteros: ";
        cin >> n;
        for (int i = 0; i < n; i++) {
            int num;
            cin >> num;
            enteros.push_back(num);
            idxEnteros.push_back(i);
        }

        // CARACTERES
        cout << "Cuantos caracteres: ";
        cin >> n;
        for (int i = 0; i < n; i++) {
            char c;
            cin >> c;
            caracteres.push_back(c);
            idxCaracteres.push_back(i);
        }

        // PERSONAS
        cout << "Cuantas personas: ";
        cin >> n;
        for (int i = 0; i < n; i++) {
            Persona p;
            cout << "Nombre: ";
            cin >> p.nombre;
            cout << "Edad: ";
            cin >> p.edad;

            personas.push_back(p);
            idxPersonas.push_back(i);
        }
    }

    // ================= QUICK ENTEROS =================
    int particionEnteros(int ini, int fin) {
        int pivote = enteros[idxEnteros[fin]];
        int i = ini - 1;

        for (int j = ini; j < fin; j++) {
            if (enteros[idxEnteros[j]] < pivote) {
                i++;
                swap(idxEnteros[i], idxEnteros[j]);
            }
        }

        swap(idxEnteros[i + 1], idxEnteros[fin]);
        return i + 1;
    }

    void quickEnteros(int ini, int fin) {
        if (ini < fin) {
            int pi = particionEnteros(ini, fin);
            quickEnteros(ini, pi - 1);
            quickEnteros(pi + 1, fin);
        }
    }

    // ================= QUICK CARACTERES =================
    int particionCaracteres(int ini, int fin) {
        char pivote = caracteres[idxCaracteres[fin]];
        int i = ini - 1;

        for (int j = ini; j < fin; j++) {
            if (caracteres[idxCaracteres[j]] < pivote) {
                i++;
                swap(idxCaracteres[i], idxCaracteres[j]);
            }
        }

        swap(idxCaracteres[i + 1], idxCaracteres[fin]);
        return i + 1;
    }

    void quickCaracteres(int ini, int fin) {
        if (ini < fin) {
            int pi = particionCaracteres(ini, fin);
            quickCaracteres(ini, pi - 1);
            quickCaracteres(pi + 1, fin);
        }
    }

    // ================= QUICK PERSONAS =================
    int particionPersonas(int ini, int fin) {
        int pivote = personas[idxPersonas[fin]].edad;
        int i = ini - 1;

        for (int j = ini; j < fin; j++) {
            if (personas[idxPersonas[j]].edad < pivote) {
                i++;
                swap(idxPersonas[i], idxPersonas[j]);
            }
        }

        swap(idxPersonas[i + 1], idxPersonas[fin]);
        return i + 1;
    }

    void quickPersonas(int ini, int fin) {
        if (ini < fin) {
            int pi = particionPersonas(ini, fin);
            quickPersonas(ini, pi - 1);
            quickPersonas(pi + 1, fin);
        }
    }

    void quicksort() {
        quickEnteros(0, idxEnteros.size() - 1);
        quickCaracteres(0, idxCaracteres.size() - 1);
        quickPersonas(0, idxPersonas.size() - 1);
    }

    void mostrar() {
        cout << "\nEnteros:\n";
        for (int i = 0; i < idxEnteros.size(); i++)
            cout << enteros[idxEnteros[i]] << " ";

        cout << "\n\nCaracteres:\n";
        for (int i = 0; i < idxCaracteres.size(); i++)
            cout << caracteres[idxCaracteres[i]] << " ";

        cout << "\n\nPersonas:\n";
        for (int i = 0; i < idxPersonas.size(); i++)
            cout << personas[idxPersonas[i]].nombre << " - "
                 << personas[idxPersonas[i]].edad << endl;
    }
};

// ================= MAIN =================
int main() {
    Ordenamiento obj;

    obj.cargarDatos();
    obj.quicksort();
    obj.mostrar();

    return 0;
}
