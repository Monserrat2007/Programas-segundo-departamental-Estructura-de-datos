#include <stdio.h>
#include "cola.h"

void inicializar(Cola *c) {
    c->frente = 0;
    c->final = -1;
}

int estaVacia(Cola *c) {
    return c->final < c->frente;
}

int estaLlena(Cola *c) {
    return c->final == MAX - 1;
}

void enqueue(Cola *c, int valor) {
    if (!estaLlena(c)) {
        c->datos[++c->final] = valor;
        printf("Elemento agregado\n");
    } else {
        printf("Cola llena\n");
    }
}

int dequeue(Cola *c) {
    if (!estaVacia(c)) {
        return c->datos[c->frente++];
    } else {
        printf("Cola vacia\n");
        return -1;
    }
}

void mostrar(Cola *c) {
    if (estaVacia(c)) {
        printf("Cola vacia\n");
        return;
    }

    for (int i = c->frente; i <= c->final; i++) {
        printf("%d\n", c->datos[i]);
    }
}

int tamano(Cola *c) {
    if (estaVacia(c)) {
        return 0;
    }
    return c->final - c->frente + 1;
}