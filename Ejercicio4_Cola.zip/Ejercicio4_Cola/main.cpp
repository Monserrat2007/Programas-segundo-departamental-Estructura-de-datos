#include <stdio.h>
#include "cola.h"
#include "ordenamientos.h"

int main() {
    Cola c;
    inicializar(&c);

    int opcion, num;

    do {
        printf("\n----- MENU -----\n");
        printf("1. Enqueue\n");
        printf("2. Dequeue\n");
        printf("3. Mostrar\n");
        printf("4. Ordenar Burbuja\n");
        printf("5. Ordenar QuickSort\n");
        printf("6. Ordenar MergeSort\n");
        printf("7. Salir\n");
        printf("Opcion: ");
        scanf("%d", &opcion);

        switch(opcion) {
            case 1:
                printf("Numero: ");
                scanf("%d", &num);
                enqueue(&c, num);
                break;

            case 2:
                printf("Eliminado: %d\n", dequeue(&c));
                break;

            case 3:
                mostrar(&c);
                break;

            case 4:
                burbuja(c.datos, tamano(&c));
                printf("Ordenado con Burbuja\n");
                mostrar(&c);
                break;

            case 5:
                quickSort(c.datos, c.frente, c.final);
                printf("Ordenado con QuickSort\n");
                mostrar(&c);
                break;

            case 6:
                mergeSort(c.datos, c.frente, c.final);
                printf("Ordenado con MergeSort\n");
                mostrar(&c);
                break;

            case 7:
                printf("Saliendo...\n");
                break;

            default:
                printf("Opcion invalida\n");
        }

    } while(opcion != 7);

    return 0;
}