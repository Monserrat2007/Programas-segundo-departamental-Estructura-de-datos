#ifndef COLA_H
#define COLA_H

#define MAX 50

typedef struct {
    int datos[MAX];
    int frente;
    int final;
} Cola;

void inicializar(Cola *c);
void enqueue(Cola *c, int valor);
int dequeue(Cola *c);
int estaVacia(Cola *c);
int estaLlena(Cola *c);
void mostrar(Cola *c);
int tamano(Cola *c);

#endif